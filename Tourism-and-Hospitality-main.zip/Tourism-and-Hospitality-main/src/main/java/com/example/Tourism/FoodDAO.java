package com.example.Tourism;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FoodDAO extends JpaRepository<Food, Long>{
}
